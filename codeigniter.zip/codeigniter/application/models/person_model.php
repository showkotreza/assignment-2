<?php
class person_model extends CI_Model 
{
	/*Insert*/
	function saverecords($first_name,$last_name,$email)
	{

	    $query="insert into person values('','$first_name','$last_name','$email')";
	    $this->db->query($query);
    }

    function display_records()
    
    {
	    $query=$this->db->query("select * from person");
        return $query->result();
    
    }
    function displayrecordsById($id)
	{
	$query=$this->db->query("select * from person where id='".$id."'");
	return $query->result();
    }
    function update_records($first_name,$last_name,$email,$id)
	{
	$query=$this->db->query("update person SET first_name='$first_name',last_name='$last_name',email='$email' where id='$id'");
    }
    
    function deleterecords($id)
	{
	$this->db->query("delete  from person where id='".$id."'");
	}
	
}