<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class v extends CI_Controller {  
      
    public function index()  
    {  
        $this->load->view('hello_world');  
    }  
}  
?>  




<?php 
class person extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('Crud_model');
	}
        /*Insert*/
	public function savedata()
	{
		/*load registration view form*/
		$this->load->view('insert_person');
	
		/*Check submit button */
		if($this->input->post('save'))
		{
		
		$first_name=$this->input->post('first_name');
		$last_name=$this->input->post('last_name');
		$email=$this->input->post('email');
		
		$this->person_model->saverecords($first_name,$last_name,$email);	
		echo "Records Saved Successfully";
		}
	}
	
}
?>