<?php 
class person extends CI_Controller 
{


	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('person_model');
	}
        /*Insert*/

       
	public function savedata()
	{
		/*load registration view form*/
		$this->load->view('insert_person');
	
		/*Check submit button */
		if($this->input->post('save'))
		{
		
		$first_name=$this->input->post('first_name');
		$last_name=$this->input->post('last_name');
		$email=$this->input->post('email');
		
		$this->person_model->saverecords($first_name,$last_name,$email);	
		//echo "Records Saved Successfully";
		
		$this->load->helper('url');
		redirect('person/displaydata');
		echo "<script>alert('Records Saved Successfully !')</script>"; 
		}
    }

    public function displaydata()
	{
	echo "<a href='savedata'>insert data <a><br>";
	$result['data']=$this->person_model->display_records();
	$this->load->view('display_records',$result);
    }
    
    public function updatedata()
	{
	$id=$this->input->get('id');
	$result['data']=$this->person_model->displayrecordsById($id);
	$this->load->view('update_records',$result);
	
		if($this->input->post('update'))
		{
		$first_name=$this->input->post('first_name');
		$last_name=$this->input->post('last_name');
		$email=$this->input->post('email');
		$this->person_model->update_records($first_name,$last_name,$email,$id);
		//echo "Date updated successfully ! ";
		echo '<script>alert("Date updated successfully !")</script>'; 
		$this->load->helper('url');
		redirect('person/displaydata');
		}
    }
    public function deletedata()
	{
	$id=$this->input->get('id');
	$this->person_model->deleterecords($id);
	//echo "Date deleted successfully !";
	echo '<script>alert("Date deleted successfully !")</script>'; 
		$this->load->helper('url');
		redirect('person/displaydata');


	}
	
}

?>